# Set up ARGoS compilation information
include_directories(${CMAKE_SOURCE_DIR} ${ARGOS_INCLUDE_DIRS})
link_directories(${ARGOS_LIBRARY_DIRS})
link_directories(
	${CMAKE_BINARY_DIR}/src
    )

#add_subdirectory(chocolate)
#add_subdirectory(example)
add_subdirectory(gianduja)
add_subdirectory(mate)
#add_subdirectory(vanilla)
