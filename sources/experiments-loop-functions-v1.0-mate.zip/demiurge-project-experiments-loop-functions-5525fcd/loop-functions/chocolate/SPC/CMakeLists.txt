add_library(chocolate_spc_loopfunc SHARED ChocolateSPCLoopFunc.h ChocolateSPCLoopFunc.cpp ${LOOP_HEADERS} ${LOOP_SOURCES})
target_link_libraries(chocolate_spc_loopfunc argos3plugin_${ARGOS_BUILD_FOR}_epuck)
